# AIRPORTCHA AI 开发助手持续工作规范（AGENTS.md）

> 本文件供所有后续接手本项目的 AI 编程助手在每次任务开始前读取并严格遵守。

---

## 1. 核心架构红线（不可违背）

1. **必须保持原生 WordPress 架构**：禁止将项目改为纯静态 HTML、Next.js、Hexo 等非 WordPress 方案。
2. **严禁硬编码业务内容**：首页推荐、品牌目录、品牌对比、文章列表必须全部通过 `WP_Query` / WordPress 数据库动态读取，确保站长在后台更新后全站自动同步。
3. **保持插件与主题解耦**：
   - 所有 CPT、Taxonomy、Meta 字段、短代码、SEO、重定向、Seeder 必须放在 `wp-content/plugins/airportcha-core/`。
   - 模板、样式、前端交互放在 `wp-content/themes/airportcha/`。
4. **保持独立科技媒体定位**：
   - 「光年梯」是重点推荐品牌之一，但**绝不能**把网站改成光年梯官网或单一产品落地页。
   - 所有推广外链必须保留 `rel="nofollow sponsored noopener"`。

---

## 2. 视觉与代码修改规范

1. **遵守既有设计系统**：沿用 `DESIGN_SYSTEM.md` 中定义的 CSS 变量（`--ac-navy: #101B32`、`--ac-blue: #3789FF`、`--ac-purple: #8067F5`、`--ac-bg: #F5F8FD`、`--ac-text: #202B3C`），不要随意更换整体视觉风格。
2. **保持轻量化**：优先使用原生 CSS 与无依赖原生 JS，不引入重型前端框架或臃肿的第三方库。
3. **保护用户数据安全**：
   - 修改 `seeder.php` 时，必须保持**幂等且不覆盖用户已修改内容**的原则（已存在则直接返回 ID）。
   - 所有表单保存必须包含 `wp_verify_nonce()`、`current_user_can()` 权限检查以及 `sanitize_*` / `esc_*` 清洗转义。
4. **SEO 插件兼容**：修改 `includes/seo.php` 时，必须保留 `airportcha_has_external_seo_plugin()` 检测，避免与 Rank Math / Yoast SEO 冲突。

---

## 3. 路由与兼容性保护

- 严禁随意更改已确定的核心 URL：`/`、`/recommend/`、`/brands/`、`/brands/{slug}/`、`/reviews/`、`/reviews/{slug}/`、`/comparisons/`、`/blog/`、`/guides/`、`/knowledge/`、`/about/`。
- 不要移除 `package.json` 中对 `@wp-playground/cli@3.1.65` 的版本锁定（除非已实测新版本在 `registry.npmmirror.com` 下无依赖解析错误）。
- 不要在 `blueprint.json` 中重新加入 `login` step（会导致无状态请求 302 重定向循环）。

---

## 4. 验收与安全要求

- 每次功能改动后，建议通过 `npm start`（`http://127.0.0.1:9400/`）实际启动 WordPress 验证前后台渲染无 PHP 报错。
- 严禁在代码、Git 提交或文档中写入任何真实的数据库密码、API Key、Token 或用户敏感凭证。
- 未经用户明确确认，不要删除已有业务文件、不要修改正式域名 DNS。
